t = '''
#####    #####
#     ##     #
#    ####    #
#   ######   #
  #   ##   #  
 ##   ##   ## 
##############
##############
 ##   ##   ## 
  #   ##   #  
#   ######   #
#    ####    #
#     ##     #
#####    #####
'''

ls = t.split('\n')[1:-1]
if len(ls) != 14:
	print(len(ls))
	exit(1)
for l in ls:
	for c in l:
		if c == ' ':
			print('0xff, ', end = '')
		else:
			print('0x00, ', end = '')
	print()
