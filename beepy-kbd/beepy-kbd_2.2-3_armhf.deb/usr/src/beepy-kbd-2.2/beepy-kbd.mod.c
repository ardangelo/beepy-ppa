#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif


static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x54b489af, "filp_open" },
	{ 0x59f94684, "devm_request_threaded_irq" },
	{ 0x5997e718, "devm_kmalloc" },
	{ 0x77bc13a0, "strim" },
	{ 0xb2d48a2e, "queue_work_on" },
	{ 0xefd6cf06, "__aeabi_unwind_cpp_pr0" },
	{ 0xdd64f5ef, "devm_input_allocate_device" },
	{ 0x5552af58, "param_set_charp" },
	{ 0x7e0e3454, "devm_rtc_device_register" },
	{ 0x92997ed8, "_printk" },
	{ 0xbd2f0cd2, "input_register_device" },
	{ 0x3ea1b6e4, "__stack_chk_fail" },
	{ 0xef0da48, "_dev_info" },
	{ 0x8b022a5c, "i2c_register_driver" },
	{ 0xfabe0da1, "devm_kmemdup" },
	{ 0x64a4ac86, "_dev_err" },
	{ 0x8c8569cb, "kstrtoint" },
	{ 0xa7eedcc4, "call_usermodehelper" },
	{ 0xee7580da, "input_set_capability" },
	{ 0x84b183ae, "strncmp" },
	{ 0x328a05f1, "strncpy" },
	{ 0x71c85918, "sysfs_create_group" },
	{ 0xf8eec93b, "firmware_kobj" },
	{ 0xae29bb08, "_dev_warn" },
	{ 0x8a7fdd2b, "i2c_smbus_read_word_data" },
	{ 0xd9efa07b, "param_get_charp" },
	{ 0x7f1daf13, "input_event" },
	{ 0xb27cb82d, "kobject_create_and_add" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xb1ad28e0, "__gnu_mcount_nc" },
	{ 0xea43bfbd, "filp_close" },
	{ 0x3bb90c4c, "i2c_smbus_write_byte_data" },
	{ 0xb57160d3, "i2c_del_driver" },
	{ 0x8300e915, "i2c_smbus_read_byte_data" },
	{ 0x2d3385d3, "system_wq" },
	{ 0xee9ca12e, "kobject_put" },
	{ 0x91ade18, "module_layout" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("of:N*T*Cbeepy-kbd");
MODULE_ALIAS("of:N*T*Cbeepy-kbdC*");
MODULE_ALIAS("i2c:beepy-kbd");

MODULE_INFO(srcversion, "86FE2EED74AFDA83DE6D64E");
