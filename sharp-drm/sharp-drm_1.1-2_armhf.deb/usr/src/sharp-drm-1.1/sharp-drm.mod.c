#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif


static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x78d0063d, "drm_open" },
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
	{ 0x3e4d0f8f, "drm_poll" },
	{ 0x99490da5, "drm_gem_fb_end_cpu_access" },
	{ 0x599b26ec, "drm_dev_enter" },
	{ 0x9b753afb, "__class_create" },
	{ 0x5997e718, "devm_kmalloc" },
	{ 0x9490a1b5, "gpiod_set_value" },
	{ 0xcb67699a, "drm_plane_enable_fb_damage_clips" },
	{ 0xefd6cf06, "__aeabi_unwind_cpp_pr0" },
	{ 0x7f3bc6a3, "drm_gem_prime_mmap" },
	{ 0x4349401a, "drm_atomic_helper_shutdown" },
	{ 0x40a86756, "class_destroy" },
	{ 0x72404117, "drm_connector_helper_get_modes_fixed" },
	{ 0xc3055d20, "usleep_range_state" },
	{ 0x2b24ba26, "drm_fb_dma_get_gem_obj" },
	{ 0xe587f346, "drm_gem_prime_handle_to_fd" },
	{ 0xad85a150, "drmm_mode_config_init" },
	{ 0x83f63da3, "devm_gpiod_put" },
	{ 0x92997ed8, "_printk" },
	{ 0x3ea1b6e4, "__stack_chk_fail" },
	{ 0x26ed33a, "drm_atomic_helper_commit" },
	{ 0xef87722c, "drm_atomic_helper_check" },
	{ 0xb88d81b8, "drm_atomic_helper_connector_destroy_state" },
	{ 0xb00df3aa, "drm_gem_mmap" },
	{ 0xd56405ce, "drm_ioctl" },
	{ 0xc6ad890e, "drm_gem_prime_fd_to_handle" },
	{ 0x6c7903e2, "cdev_add" },
	{ 0x60e2f492, "spi_sync" },
	{ 0x94dee2b4, "drm_dev_unplug" },
	{ 0x60a20f8c, "drm_connector_init" },
	{ 0x92fac732, "drm_gem_simple_display_pipe_prepare_fb" },
	{ 0x8e865d3c, "arm_delay_ops" },
	{ 0x8c8569cb, "kstrtoint" },
	{ 0xd0b2c695, "drm_atomic_helper_damage_merged" },
	{ 0xc38c83b8, "mod_timer" },
	{  0x321eb, "device_create" },
	{ 0x7358a503, "noop_llseek" },
	{ 0xdd55e60f, "drm_read" },
	{ 0x119d4189, "drm_gem_fb_create_with_dirty" },
	{ 0x915fd6cb, "drm_gem_dma_dumb_create" },
	{ 0xc90068d, "driver_unregister" },
	{ 0xe8a034df, "drm_dev_exit" },
	{ 0xe5a95294, "__devm_drm_dev_alloc" },
	{ 0x5f754e5a, "memset" },
	{ 0xae29bb08, "_dev_warn" },
	{ 0x97934ecf, "del_timer_sync" },
	{ 0xf3282047, "drm_fbdev_generic_setup" },
	{ 0xb2844a10, "drm_atomic_helper_connector_duplicate_state" },
	{ 0x84a78eca, "drm_simple_display_pipe_init" },
	{ 0xb5ddc20b, "drm_connector_cleanup" },
	{ 0x526c3a6c, "jiffies" },
	{ 0xdbabef87, "dma_set_coherent_mask" },
	{ 0x2d23b0cd, "param_set_int" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0x3aa9e1bb, "drm_gem_fb_begin_cpu_access" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0xb1ad28e0, "__gnu_mcount_nc" },
	{ 0xdabde2d7, "__spi_register_driver" },
	{ 0x95f617af, "devm_gpiod_get" },
	{ 0x2d0794ac, "device_destroy" },
	{ 0x97413bee, "drm_helper_probe_single_connector_modes" },
	{ 0xb7998728, "drm_fb_xrgb8888_to_gray8" },
	{ 0xb016a13a, "dma_set_mask" },
	{ 0x9c132ecc, "drm_atomic_helper_connector_reset" },
	{ 0xe614d69f, "dev_err_probe" },
	{ 0xb22d9e05, "drm_mode_config_reset" },
	{ 0x50f247e, "drm_gem_dma_prime_import_sg_table_vmap" },
	{ 0x7c112b3d, "param_get_int" },
	{ 0xa8c93227, "drm_dev_register" },
	{ 0x6603ec52, "cdev_init" },
	{ 0x6815efd6, "cdev_del" },
	{ 0x1995762b, "drm_release" },
	{ 0x91ade18, "module_layout" },
};

MODULE_INFO(depends, "drm,drm_kms_helper,drm_dma_helper");


MODULE_INFO(srcversion, "B7F19347A4A1A5CE0854748");
